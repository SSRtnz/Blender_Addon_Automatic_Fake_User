bl_info = {
    "name": "[Project Resistance] Lets Turn On Auto Fake User",
    "author": "Theiyn tnz",
    "version": (1, 0 ,0),
    "blender": (3, 0, 0),
    "location": "Below this message(Only Enable / Disable)",
    "description": "Automatically enables Fake User for all data blocks",
    "category": "System" ,
    "warning" : "First Public Version. Some function maybe has bug" ,
    "doc_url": "https://github.com/SSRtnz/Blender_Addon_Automatic_Fake_User/blob/main/%5BPDF%5DLets%20turn%20on%20auto%20Fake%20User%20manual.pdf" ,
    "tracker_url": "https://www.facebook.com/profile.php?id=61577688574948" ,
    "support" : "TESTING" ,
}
import bpy
from bpy.app.handlers import persistent
from bpy.props import BoolProperty

# --- 1. Setting Part (Preferences) ---
class AutoFakeUserPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    use_actions: BoolProperty(name="Actions (Animation)", default=True)
    use_armatures: BoolProperty(name="Armatures", default=True)
    use_brushes: BoolProperty(name="Brushes", default=True)
    use_cameras: BoolProperty(name="Cameras", default=True)
    use_curves: BoolProperty(name="Curves", default=True)
    use_images: BoolProperty(name="Images", default=True)
    use_lights: BoolProperty(name="Lights", default=True)
    use_materials: BoolProperty(name="Materials", default=True)
    use_meshes: BoolProperty(name="Meshes", default=True)
    use_node_groups: BoolProperty(name="Node Groups", default=True)
    use_particles: BoolProperty(name="Particles", default=True)
    use_texts: BoolProperty(name="Texts", default=True)
    use_textures: BoolProperty(name="Textures", default=True)
    use_worlds: BoolProperty(name="Worlds", default=True)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Enable Auto Fake User for:")
        # column_flow จะช่วยจัดระเบียบปุ่มให้แบ่งเป็น 2 คอลัมน์ดูง่ายขึ้น
        column = layout.column_flow(columns=2)
        column.prop(self, "use_actions")
        column.prop(self, "use_armatures")
        column.prop(self, "use_brushes")
        column.prop(self, "use_cameras")
        column.prop(self, "use_curves")
        column.prop(self, "use_images")
        column.prop(self, "use_lights")
        column.prop(self, "use_materials")
        column.prop(self, "use_meshes")
        column.prop(self, "use_node_groups")
        column.prop(self, "use_particles")
        column.prop(self, "use_texts")
        column.prop(self, "use_textures")
        column.prop(self, "use_worlds")

# --- 2. Main system ---
@persistent
def auto_set_fake_user(scene):
    # ป้องกัน Error หากหา Addon ไม่เจอ
    addon = bpy.context.preferences.addons.get(__name__)
    if not addon:
        return
    
    prefs = addon.preferences
    
    # สังเกตเครื่องหมาย , ท้ายบรรทัดนะครับ สำคัญมาก!
    mapping = [
        (prefs.use_actions, bpy.data.actions),
        (prefs.use_armatures, bpy.data.armatures),
        (prefs.use_brushes, bpy.data.brushes),
        (prefs.use_cameras, bpy.data.cameras),
        (prefs.use_curves, bpy.data.curves),
        (prefs.use_images, bpy.data.images),
        (prefs.use_lights, bpy.data.lights),
        (prefs.use_materials, bpy.data.materials),
        (prefs.use_meshes, bpy.data.meshes),
        (prefs.use_node_groups, bpy.data.node_groups),
        (prefs.use_particles, bpy.data.particles),
        (prefs.use_texts, bpy.data.texts),
        (prefs.use_textures, bpy.data.textures),
        (prefs.use_worlds, bpy.data.worlds)
    ]
    
    for should_run, collection in mapping:
        if should_run:
            for item in collection:
                # ตรวจสอบว่ามีคุณสมบัติ use_fake_user และยังไม่ได้ถูกเปิด
                if hasattr(item, "use_fake_user") and not item.use_fake_user:
                    item.use_fake_user = True

# --- 3. Registration ---
def register():
    bpy.utils.register_class(AutoFakeUserPreferences)
    if auto_set_fake_user not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(auto_set_fake_user)

def unregister():
    if auto_set_fake_user in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(auto_set_fake_user)
    bpy.utils.unregister_class(AutoFakeUserPreferences)

if __name__ == "__main__":
    register()